# Project Improvement Status

Last updated: 2026-04-16

## Completed

- Phase 0 rollback baseline is in place.
  - Canonical rollback tooling exists in `src/volpred/ops/rollback.py`
  - Multiple named rollback points have been created under `storage/ops/rollback_points/`
- Root-level low-risk repo cleanup is in place.
  - Root clutter has been consolidated into `archive/root-clutter/`
  - Hygiene tooling exists in `src/volpred/ops/hygiene.py`
- Phase 0.5 agent-spec canonical is in place.
  - Canonical source: `agent-specs/`
  - Generated outputs: `CLAUDE.md`, `AGENTS.md`, `.claude/...`, `.agents/...`
  - Agent-spec tooling exists in `src/volpred/ops/agent_spec.py`
- Phase 1 local VS Code control plane is in place.
  - Local task state: `storage/ops/tasks/`, `storage/ops/agents/`, `storage/ops/executions/`, `storage/ops/approvals/`
  - Local control plane implementation: `src/volpred/ops/local_control_plane.py`
  - CLI wiring: `src/volpred/cli.py`
- Website zero-regression guardrails are in place.
  - Frontend regression verifier: `frontend-v2-fix/scripts/verify-regressions.mjs`
  - Web admin mirror for local control plane is in place
- `.venv` dev/test environment is usable.
  - `uv sync --extra dev` has been run
  - `pytest` is available through the repo `.venv`
- `experiments/` touched-file migration tooling is in place.
  - Implementation: `src/volpred/ops/experiments.py`
  - Tests: `tests/test_experiments_ops.py`

## In Progress

- Historical `experiments/` normalization.
  - Strategy: new-rule-first + touched-file migration
  - Current hygiene snapshot:
    - `loose_files=1215`
    - `candidate_groups=663`
  - Recently migrated batches include:
    - `k625`, `i3`, `i6`
    - `k622`, `k628b`, `k634`
    - `k811v2`, `k521`, `k621`
    - `k635`, `k636`, `k642`
    - `k851`, `I1`, `k745`
    - `K158`, `i0`, `i10`
    - `i11`, `i12`, `i1b`
    - `i5`, `i8`, `i9`
    - `i9b`, `k142`, `k145`
    - `k147`, `k148`, `k149`
    - `k151`, `k152`, `k157`
    - `k159`, `k180`, `k181`
    - `k182`, `k186`, `k188`

## Partial

- Phase 2 schedule/cost convergence is only partially complete.
  - Core direction is implemented
  - Some legacy schedules still exist and have not all been fully re-homed into the final local control-plane model
- Website admin remains an observer, not the canonical control plane.
  - This is intentional for v1
  - Further admin surfacing can still be improved

## Remaining

- Continue batch migration for remaining `experiments/` loose files.
  - Current top candidates:
    - `k189`
    - `k190`
    - `k191`
    - `k193`
    - `k194`
- Remove or normalize ungrouped loose files in `experiments/`
  - Examples:
    - `.DS_Store`
    - `behavioral_vt_barriers.py`
    - `btc_derivatives_vol.py`
    - `btc_liquidation_abm.py`
    - `btc_var_methods.py`
- Optional next cleanup:
  - Add targeted tests for more migrated experiment families
  - Continue refining legacy schedule definitions into the local control plane

## Current Readout

- Core improvement plan status:
  - Rollback / safety: complete
  - Agent-spec canonical sync: complete
  - Local dual-agent control plane: complete for v1
  - Website regression / observer layer: complete for v1
  - Historical experiments cleanup: ongoing
