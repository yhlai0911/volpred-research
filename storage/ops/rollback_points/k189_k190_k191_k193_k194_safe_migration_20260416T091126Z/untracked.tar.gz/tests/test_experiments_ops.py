from pathlib import Path

from volpred.ops.experiments import (
    build_experiment_migration_plan,
    build_experiments_report,
    migrate_experiment_files,
    scaffold_experiment,
)


def test_build_experiments_report_groups_loose_files(tmp_path: Path):
    experiments_dir = tmp_path / "experiments"
    experiments_dir.mkdir()
    (experiments_dir / "k100.py").write_text("print('x')\n", encoding="utf-8")
    (experiments_dir / "k100_results.json").write_text("{}\n", encoding="utf-8")
    (experiments_dir / "k100_plot.png").write_text("png", encoding="utf-8")
    (experiments_dir / "notes.txt").write_text("misc\n", encoding="utf-8")
    (experiments_dir / "k200").mkdir()
    (experiments_dir / "k200" / "README.md").write_text("# K200\n", encoding="utf-8")

    report = build_experiments_report(root_path=tmp_path, limit=10)

    assert report["loose_file_count"] == 4
    assert report["top_level_dir_count"] == 1
    assert report["candidate_count"] == 1
    assert report["grouped_candidates"][0]["experiment_id"] == "k100"
    assert report["grouped_candidates"][0]["loose_count"] == 3
    assert report["ungrouped_loose_files"] == ["experiments/notes.txt"]


def test_scaffold_experiment_creates_canonical_layout(tmp_path: Path):
    result = scaffold_experiment("k321", title="My Experiment", root_path=tmp_path)
    experiment_dir = tmp_path / "experiments" / "k321"

    assert result["target_dir"] == "experiments/k321"
    assert (experiment_dir / "README.md").exists()
    assert (experiment_dir / "k321.py").exists()
    assert (experiment_dir / "k321_results.json").exists()
    assert (experiment_dir / "references" / ".gitkeep").exists()
    assert (experiment_dir / "data" / ".gitkeep").exists()


def test_migrate_experiment_files_moves_only_touched_group(tmp_path: Path):
    experiments_dir = tmp_path / "experiments"
    experiments_dir.mkdir()
    (experiments_dir / "k555.py").write_text("print('main')\n", encoding="utf-8")
    (experiments_dir / "k555_plots.py").write_text("print('plots')\n", encoding="utf-8")
    (experiments_dir / "k555_results.json").write_text("{}\n", encoding="utf-8")
    (experiments_dir / "k556.py").write_text("print('other')\n", encoding="utf-8")
    (tmp_path / "docs").mkdir()
    (tmp_path / "docs" / "notes.md").write_text(
        "See experiments/k555.py and experiments/k555_results.json\n",
        encoding="utf-8",
    )

    plan = build_experiment_migration_plan("k555", root_path=tmp_path)
    assert len(plan["moves"]) == 3
    assert plan["conflicts"] == []
    k555_move = next(item for item in plan["moves"] if item["source"] == "experiments/k555.py")
    assert k555_move["reference_hit_count"] >= 1

    result = migrate_experiment_files("k555", root_path=tmp_path, apply_changes=True)
    experiment_dir = tmp_path / "experiments" / "k555"

    assert result["dry_run"] is False
    assert sorted(item["source"] for item in result["moved"]) == [
        "experiments/k555.py",
        "experiments/k555_plots.py",
        "experiments/k555_results.json",
    ]
    assert (experiment_dir / "k555.py").exists()
    assert (experiment_dir / "k555_plots.py").exists()
    assert (experiment_dir / "k555_results.json").exists()
    assert (tmp_path / "experiments" / "k556.py").exists()
    assert not (tmp_path / "experiments" / "k555.py").exists()


def test_migrate_dry_run_does_not_create_scaffold(tmp_path: Path):
    experiments_dir = tmp_path / "experiments"
    experiments_dir.mkdir()
    (experiments_dir / "k777.py").write_text("print('main')\n", encoding="utf-8")

    result = migrate_experiment_files("k777", root_path=tmp_path, apply_changes=False)

    assert result["dry_run"] is True
    assert "experiments/k777/README.md" in result["planned_created"]
    assert result["created"] == []
    assert not (tmp_path / "experiments" / "k777").exists()


def test_scaffold_plan_skips_gitkeep_for_non_empty_data_dir(tmp_path: Path):
    experiment_dir = tmp_path / "experiments" / "k888"
    data_dir = experiment_dir / "data"
    data_dir.mkdir(parents=True)
    (data_dir / "panel.parquet").write_text("data", encoding="utf-8")

    result = migrate_experiment_files("k888", root_path=tmp_path, apply_changes=False)

    assert "experiments/k888/README.md" in result["planned_created"]
    assert "experiments/k888/references/.gitkeep" in result["planned_created"]
    assert "experiments/k888/data/.gitkeep" not in result["planned_created"]


def test_migrate_can_rewrite_repo_references(tmp_path: Path):
    experiments_dir = tmp_path / "experiments"
    experiments_dir.mkdir()
    source_script = experiments_dir / "k625_hurst_volatility.py"
    source_results = experiments_dir / "k625_hurst_volatility_results.json"
    legacy_script_ref = "experiments/" + "k625_hurst_volatility.py"
    legacy_results_ref = "experiments/" + "k625_hurst_volatility_results.json"
    source_script.write_text(
        f'results_path = "{legacy_results_ref}"\n',
        encoding="utf-8",
    )
    source_results.write_text(
        '{"script":"' + legacy_script_ref + '"}\n',
        encoding="utf-8",
    )
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    notes = docs_dir / "notes.md"
    notes.write_text(
        f"See {legacy_script_ref} and {legacy_results_ref}\n",
        encoding="utf-8",
    )

    result = migrate_experiment_files(
        "k625",
        root_path=tmp_path,
        apply_changes=True,
        rewrite_references=True,
    )

    moved_script = tmp_path / "experiments" / "k625" / "k625_hurst_volatility.py"
    moved_results = tmp_path / "experiments" / "k625" / "k625_hurst_volatility_results.json"
    assert moved_script.exists()
    assert moved_results.exists()
    assert "experiments/k625/k625_hurst_volatility_results.json" in moved_script.read_text(encoding="utf-8")
    assert "experiments/k625/k625_hurst_volatility.py" in moved_results.read_text(encoding="utf-8")
    assert "experiments/k625/k625_hurst_volatility.py" in notes.read_text(encoding="utf-8")
    assert any(update["files"] for update in result["reference_updates"])
