from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .common import project_path

CANONICAL_ROOT = project_path("agent-specs")
CANONICAL_GUIDE = CANONICAL_ROOT / "guide.md"
CANONICAL_SKILLS = CANONICAL_ROOT / "skills"
CANONICAL_REFERENCES = CANONICAL_ROOT / "references"

GENERATED_HEADER = "<!-- AUTO-GENERATED FROM agent-specs/. Edit canonical sources instead. -->\n\n"
PLACEHOLDERS = {
    "guide_file": "{{GUIDE_FILE}}",
    "skill_root": "{{SKILL_ROOT}}",
    "provider_dir": "{{PROVIDER_DIR}}",
}


@dataclass(frozen=True)
class AgentSpecTarget:
    key: str
    guide_path: Path
    skills_path: Path
    guide_name: str
    skill_root: str
    provider_dir: str


TARGETS = {
    "claude": AgentSpecTarget(
        key="claude",
        guide_path=project_path("CLAUDE.md"),
        skills_path=project_path(".claude", "skills"),
        guide_name="CLAUDE.md",
        skill_root=".claude/skills",
        provider_dir=".claude",
    ),
    "codex": AgentSpecTarget(
        key="codex",
        guide_path=project_path("AGENTS.md"),
        skills_path=project_path(".agents", "skills"),
        guide_name="AGENTS.md",
        skill_root=".agents/skills",
        provider_dir=".agents",
    ),
}


def ensure_agent_spec_dirs() -> None:
    CANONICAL_ROOT.mkdir(parents=True, exist_ok=True)
    CANONICAL_SKILLS.mkdir(parents=True, exist_ok=True)
    CANONICAL_REFERENCES.mkdir(parents=True, exist_ok=True)
    readme = CANONICAL_REFERENCES / "README.md"
    if not readme.exists():
        readme.write_text("# Shared References\n\nProvider-neutral references live here when needed.\n")


def _strip_generated_header(text: str) -> str:
    if text.startswith(GENERATED_HEADER):
        return text[len(GENERATED_HEADER) :]
    return text


def _normalize_text(text: str) -> str:
    text = _strip_generated_header(text)
    replacements = (
        (".claude/skills", PLACEHOLDERS["skill_root"]),
        (".agents/skills", PLACEHOLDERS["skill_root"]),
        (".claude/", f"{PLACEHOLDERS['provider_dir']}/"),
        (".agents/", f"{PLACEHOLDERS['provider_dir']}/"),
        ("CLAUDE.md", PLACEHOLDERS["guide_file"]),
        ("AGENTS.md", PLACEHOLDERS["guide_file"]),
    )
    for old, new in replacements:
        text = text.replace(old, new)
    return text


def _render_text(text: str, target: AgentSpecTarget) -> str:
    rendered = text
    replacements = (
        (PLACEHOLDERS["guide_file"], target.guide_name),
        (PLACEHOLDERS["skill_root"], target.skill_root),
        (PLACEHOLDERS["provider_dir"], target.provider_dir),
    )
    for old, new in replacements:
        rendered = rendered.replace(old, new)
    return GENERATED_HEADER + rendered


def _iter_files(root: Path) -> Iterable[Path]:
    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue
        if path.name in {".DS_Store"}:
            continue
        if "__pycache__" in path.parts:
            continue
        yield path


def _load_text(path: Path) -> str:
    return path.read_text()


def import_agent_specs(
    *,
    source: str,
    include_guide: bool = True,
    include_skills: bool = True,
) -> dict[str, object]:
    if source not in TARGETS:
        raise ValueError(f"Unknown source provider: {source}")
    ensure_agent_spec_dirs()
    target = TARGETS[source]
    copied_files: list[str] = []

    if include_guide:
        guide_text = _normalize_text(_load_text(target.guide_path))
        CANONICAL_GUIDE.write_text(guide_text)
        copied_files.append(str(CANONICAL_GUIDE.relative_to(project_path())))

    if include_skills:
        if CANONICAL_SKILLS.exists():
            shutil.rmtree(CANONICAL_SKILLS)
        CANONICAL_SKILLS.mkdir(parents=True, exist_ok=True)
        for path in _iter_files(target.skills_path):
            relative = path.relative_to(target.skills_path)
            destination = CANONICAL_SKILLS / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            try:
                destination.write_text(_normalize_text(_load_text(path)))
            except UnicodeDecodeError:
                shutil.copy2(path, destination)
            copied_files.append(str(destination.relative_to(project_path())))

    return {
        "source": source,
        "guide_imported": include_guide,
        "skills_imported": include_skills,
        "copied_files": copied_files,
    }


def _render_skills(target: AgentSpecTarget) -> list[str]:
    if target.skills_path.exists():
        shutil.rmtree(target.skills_path)
    target.skills_path.mkdir(parents=True, exist_ok=True)
    rendered_files: list[str] = []
    for path in _iter_files(CANONICAL_SKILLS):
        relative = path.relative_to(CANONICAL_SKILLS)
        destination = target.skills_path / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            destination.write_text(_render_text(_load_text(path), target))
        except UnicodeDecodeError:
            shutil.copy2(path, destination)
        rendered_files.append(str(destination.relative_to(project_path())))
    return rendered_files


def render_agent_specs(*, target_key: str | None = None) -> dict[str, object]:
    ensure_agent_spec_dirs()
    targets = [TARGETS[target_key]] if target_key else list(TARGETS.values())
    rendered: dict[str, list[str]] = {}
    for target in targets:
        target.guide_path.write_text(_render_text(_load_text(CANONICAL_GUIDE), target))
        rendered_files = [str(target.guide_path.relative_to(project_path()))]
        rendered_files.extend(_render_skills(target))
        rendered[target.key] = rendered_files
    return {"targets": rendered}


def check_agent_specs(*, target_key: str | None = None) -> dict[str, object]:
    ensure_agent_spec_dirs()
    targets = [TARGETS[target_key]] if target_key else list(TARGETS.values())
    issues: list[str] = []
    for target in targets:
        expected_guide = _render_text(_load_text(CANONICAL_GUIDE), target)
        actual_guide = _load_text(target.guide_path) if target.guide_path.exists() else None
        if actual_guide != expected_guide:
            issues.append(f"{target.guide_path.relative_to(project_path())}: drift")

        expected_rel_paths = {
            path.relative_to(CANONICAL_SKILLS)
            for path in _iter_files(CANONICAL_SKILLS)
        }
        actual_rel_paths = {
            path.relative_to(target.skills_path)
            for path in _iter_files(target.skills_path)
        } if target.skills_path.exists() else set()

        for missing in sorted(expected_rel_paths - actual_rel_paths):
            issues.append(f"{target.skills_path.relative_to(project_path())}/{missing}: missing")
        for extra in sorted(actual_rel_paths - expected_rel_paths):
            issues.append(f"{target.skills_path.relative_to(project_path())}/{extra}: unexpected")

        for relative in sorted(expected_rel_paths & actual_rel_paths):
            expected_text = _render_text(_load_text(CANONICAL_SKILLS / relative), target)
            actual_text = _load_text(target.skills_path / relative)
            if actual_text != expected_text:
                issues.append(f"{target.skills_path.relative_to(project_path())}/{relative}: drift")

    return {
        "clean": not issues,
        "issues": issues,
        "targets": [target.key for target in targets],
    }
