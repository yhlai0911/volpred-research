#!/usr/bin/env bash
# launch_all_sessions.sh — 一指令啟動 3-terminal 多 agent 作業模式
#
# 做什麼：
#   1. 用 osascript 開 3 個 Terminal.app 視窗（T1 supervisor / T2 claude-worker / T3 codex-worker）
#   2. 每個視窗 cd 到專案、source bootstrap script（登記 session 到 control plane）
#   3. 把對應 role 的 first-prompt 寫到剪貼簿 + /tmp 檔
#   4. 啟動對應 CLI（claude / codex）
#   5. 你在每個視窗按 ⌘V + Enter 就把 prompt 送進 CLI，進入工作循環
#
# 前提：
#   - macOS（腳本用 osascript + pbcopy）
#   - claude CLI、codex CLI 都已安裝且 OAuth 已登入
#   - agent-specs drift 已清（否則 session-bootstrap 會被擋；可先跑
#     `uv run volpred ops agent-spec sync --from claude` 修）
#
# 用法：
#   bash scripts/launch_all_sessions.sh
#

set -eu

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROMPTS_DIR="${PROJECT_DIR}/scripts/agent_prompts"

if ! command -v osascript >/dev/null 2>&1; then
  echo "❌ 需要 macOS 的 osascript。若你在別的 OS，請手動開 3 個 terminal 各自 source bootstrap_agent_session.sh" >&2
  exit 1
fi

if [[ ! -d "${PROMPTS_DIR}" ]]; then
  echo "❌ 找不到 prompts 目錄：${PROMPTS_DIR}" >&2
  exit 1
fi

# 預先把每個 role 的 prompt 寫到 /tmp，terminal 視窗啟動時會 pbcopy 進剪貼簿
for role in supervisor worker-claude worker-codex; do
  src="${PROMPTS_DIR}/${role}.txt"
  if [[ ! -f "${src}" ]]; then
    echo "❌ 找不到 prompt 檔：${src}" >&2
    exit 1
  fi
  cp "${src}" "/tmp/volpred_prompt_${role}.txt"
done

_open_window() {
  local role="$1"
  local cli_cmd="$2"
  local title="$3"

  # 組合要在 Terminal.app 裡跑的指令：
  #   cd → source bootstrap（會 session-bootstrap + 印 usage） → 把 prompt 複製進剪貼簿 → 啟動 CLI
  local inner_cmd
  inner_cmd="cd '${PROJECT_DIR}' && "
  inner_cmd+="source scripts/bootstrap_agent_session.sh ${role} && "
  inner_cmd+="cat /tmp/volpred_prompt_${role}.txt | pbcopy && "
  inner_cmd+="printf '\\n\\033[1;33m📋 %s 的首發 prompt 已複製到剪貼簿。\\n即將啟動 %s... 進入 CLI 後按 \\u2318V + Enter 送出。\\033[0m\\n' '${title}' '${cli_cmd}' && "
  inner_cmd+="sleep 2 && "
  inner_cmd+="${cli_cmd}"

  # 轉義 double-quote 以便塞進 AppleScript
  local escaped_cmd="${inner_cmd//\\/\\\\}"
  escaped_cmd="${escaped_cmd//\"/\\\"}"

  osascript <<APPLESCRIPT
tell application "Terminal"
  activate
  do script "${escaped_cmd}"
  set custom title of front window to "${title}"
end tell
APPLESCRIPT
}

echo "🚀 啟動 3-terminal 多 agent 作業模式..."
echo

_open_window supervisor    "claude" "T1 supervisor (claude-supervisor)"
# 給 T1 一點時間先寫入 session，避免三個視窗同時搶 control_plane.lock
sleep 1
_open_window worker-claude "claude" "T2 claude-worker"
sleep 1
_open_window worker-codex  "codex"  "T3 codex-worker"

cat <<EOF

✅ 三個 Terminal.app 視窗已開啟。
   T1 視窗：bootstrap claude-supervisor → 啟動 claude
   T2 視窗：bootstrap claude-worker → 啟動 claude
   T3 視窗：bootstrap codex-worker → 啟動 codex

每個視窗看到 CLI 啟動後，按 ⌘V + Enter 把首發 prompt 送進去即可。
EOF
